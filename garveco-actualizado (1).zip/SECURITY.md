# Seguridad y publicación

- Nunca publiques `.env`, `.env.local` ni secretos de proveedores.
- Cambia `ADMIN_PASSWORD` y `ADMIN_SESSION_SECRET` antes de desplegar.
- Las claves privadas van únicamente en variables de servidor.
- No uses `localStorage` para decidir saldos, identidad, retiros o recompensas en producción.
- El endpoint `/api/theoremreach-webhook` valida firma y datos, pero no confirma la recompensa hasta conectar una base de datos con deduplicación por `transaction_id`.
- Usa HTTPS, rotación de secretos y límites de solicitudes en el proveedor de hosting.
- Revisa los permisos de cada proveedor externo y solicita el consentimiento correspondiente antes de cargar analítica o anuncios.
