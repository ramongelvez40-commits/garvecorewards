# GarvecoRewards

Panel web en Next.js 15 + TypeScript + Tailwind CSS para mostrar actividades y recompensas.

> Esta versión entrega la interfaz y los controles de seguridad básicos. No inventa saldos, usuarios, retiros ni pagos. Para publicar con dinero real todavía debes conectar un sistema de cuentas, una base de datos y un procesador de pagos.

## Requisitos

- Node.js 20 o superior
- npm 10 o superior
- Una base de datos y un proveedor de autenticación para producción

## Desarrollo local

```bash
cp .env.example .env.local
# Completa las variables necesarias
npm install
npm run dev
```

Abre `http://localhost:4028`.

## Variables de entorno

- `ADMIN_PASSWORD`: contraseña del panel administrativo. Nunca la pongas en un archivo público.
- `ADMIN_SESSION_SECRET`: secreto aleatorio distinto para firmar la sesión administrativa.
- `NEXT_PUBLIC_SITE_URL`: URL HTTPS pública; se usa para los callbacks de offerwalls.
- `NEXT_PUBLIC_THEOREMREACH_APP_ID` y `NEXT_PUBLIC_THEOREMREACH_API_KEY`: solo si el proveedor confirma que son claves públicas.
- `THEOREMREACH_SECRET_KEY`: secreto del webhook; es exclusivamente del servidor.
- `NEXT_PUBLIC_WHATSAPP_NUMBER`: número de soporte en formato internacional, solo dígitos.

Si una integración no está configurada, la aplicación la oculta en lugar de abrir enlaces de ejemplo.

## Comandos

- `npm run dev` — desarrollo en el puerto 4028
- `npm run build` — compilación de producción
- `npm run start` — servidor de producción
- `npm run type-check` — comprobación TypeScript
- `npm run lint` — ESLint sin advertencias
- `npm run format` — formateo con Prettier

## Antes de publicar

1. Configura autenticación real en servidor; el formulario de usuarios incluido solo informa que el sistema de cuentas está pendiente.
2. Persiste usuarios, saldos, transacciones y retiros en una base de datos. No uses `localStorage` como fuente de verdad financiera.
3. Implementa el webhook con una transacción idempotente por `transaction_id` antes de devolver éxito al proveedor.
4. Conecta PayPal mediante un backend seguro y validación de identidad; nunca proceses retiros desde el navegador.
5. Revisa las reglas de cada proveedor de anuncios y elimina cualquier integración que no esté aprobada.
6. Sustituye las imágenes y enlaces del catálogo por material autorizado y configura el número real de soporte.
7. Revisa los textos legales con asesoría aplicable a los países donde operarás.
8. Ejecuta `npm run type-check`, `npm run lint` y `npm run build` con las variables de producción.

## Estructura principal

```text
src/app/                 Rutas, API y páginas
src/app/components/      Componentes del panel
src/lib/                 Configuración de integraciones y utilidades
public/                  Recursos estáticos
.env.example             Plantilla sin secretos
```
